validateJS
==========

validateJS is a lightweight javascript library that helps to easily setup a variety of client side validations.
This library cuts short your coding time to set up all those pesky validations via javascript which cannot be ignored and are essential for any input form. For detailed description and documentation of validateJS methods and objects visit this page:

http://nitij.github.io/validateJS/

If you find any bugs or issues feel free to log them here:
https://github.com/Nitij/validateJS/issues

If you find this useful then please like this repo, or fork it to code this in your own way.


